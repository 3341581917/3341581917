#pragma once
#include<iostream>
#include"stuff.h"
using namespace std;
class boss:public stuff
{
public:
	boss(string name, string number, string department);
	void opptunity();
	string get_S_Name();
	void setOffice(string office);

	void setName(string name);
	void setNumber(string number);
	void setDepartment(string department);
	
	string getName();
	string getNumber();
	string getDepartment();
	string getOffice();
};