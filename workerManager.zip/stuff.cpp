#include<iostream>
using namespace std;
class Person
{
private:
    string name;
    string number;
  
};