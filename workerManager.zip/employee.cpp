#include"employee.h"
void employee::opptunity()
{
	cout << "��ɾ�����������" << endl;
}

string employee::get_S_Name()
{
	return "��ͨԱ��";
}

void employee::setOffice(string office)
{
	this->office = office;
}

void employee::setName(string name)
{
	this->name = name;
}

void employee::setNumber(string number)
{
	this->number = number;
}


void employee::setDepartment(string department)
{
	this->department = department;
}


employee::employee(string name, string number, string department)//��ʼ���б�ֻ���ڻ���Ĺ��캯�����Լ��ĳ�Ա���ݡ�
{
	this->name = name;
	this->number = number;
	this->department = department;
	
}

string employee::getName()
{
	return this->name;
}

string employee::getNumber()
{
	return this->number;
}

string employee::getDepartment()
{
	return this->department;
}

string employee::getOffice()
{
	return this->office;
}