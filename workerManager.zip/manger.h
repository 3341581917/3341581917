#pragma once
#include<iostream>
#include"stuff.h"
using namespace std;
class manger:public stuff
{
public:
	manger(string name, string number, string department);
	void opptunity();
	void setOffice(string office);
	string get_S_Name();
	void setName(string name);
	void setNumber(string number);
	void setDepartment(string department);
	string getName();
	string getNumber();
	string getDepartment();
	string getOffice();
};