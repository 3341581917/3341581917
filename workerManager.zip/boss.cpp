#include"boss.h"
void boss::opptunity()
{
	cout << "�������������" << endl;
}

string boss::get_S_Name()
{
	return "Boss";
}

void boss::setOffice(string office)
{
	this->office = office;
}

void boss::setName(string name)
{
	this->name = name;
}

void boss::setNumber(string number)
{
	this->number = number;
}


void boss::setDepartment(string department)
{
	this->department = department;
}


boss::boss(string name, string number, string department) //��ʼ���б�ֻ���ڻ���Ĺ��캯�����Լ��ĳ�Ա���ݡ�
{
	this->name = name;
	this->number = number;
	this->department = department;
	
}

string boss::getName()
{
	return this->name;
}

string boss::getNumber()
{
	return this->number;
}

string boss::getDepartment()
{
	return this->department;
}

string boss::getOffice()
{
	return this->office;
}